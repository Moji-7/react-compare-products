export const entity = {
  url: "https://www.google.com/"
};
