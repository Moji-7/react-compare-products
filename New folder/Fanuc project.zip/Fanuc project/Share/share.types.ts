export interface ShareProps {
  url?: string;
}
